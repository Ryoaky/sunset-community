$(function(){
    
});


function isNull(){
    if (value==null||value==""){
        alert("不能为空");
        return false
    }
    else {
        return true
    }
}

function textVali(field, msg){
    if(field){

    }
}